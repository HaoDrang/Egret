0) Install Unity (DO NOT RUN IT).

1) Run patch as Administrator.

2) Select "Unity folder" by pressing "Browse" button.
OR
Copy the "Patch file" in "Unity folder".
(default : "C:\Program Files (x86)\Unity\Editor")

3) Select Unity version by pressing "drop-down menu" (if needed).

4) Click the "Patch" button to start the patching process.

Done.

////////////////////////////////////////////
//Manual License installation

The Patch automatically creates "Unity_v4.x.ulf" file in "Environment.SpecialFolder.CommonApplicationData + /Unity" or in specifed folder (if error).
You can create other fake license, go in patch and use "CreLic" button to create new one.

1) Activate unity manually without connection to internet. 

OR :
Copy the "Unity_v4.x.ulf" in:

Win8, Win7, WinVista :
C:\ProgramData\Unity
(create folder if not exist)

WinXP :
C:\Documents and Settings\All Users\Program Data\Unity
(create folder if not exist)

Done.

////////////////////////////////////////////
//Errors

"No acces to path ..."!!!
fix: (file - folder) - properties - safety - edit


"Pattern not found!!"
File is already patched or not supported by the patch.
